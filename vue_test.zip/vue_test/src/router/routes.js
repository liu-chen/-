import classify from '../pages/classify/classify'
import deserve from '../pages/deserve/deserve'
import homepage from '../pages/homepage/homepage'
import personage from '../pages/personage/personage'
import trolley from '../pages/trolley/trolley'

export default[
    {
        path: '/classify',
        component: classify,
        meta: {
          isShowFooter: true
        }
      },
      {
        path: '/deserve',
        component: deserve,
        meta: {
          isShowFooter: true
        }
      },
      {
        path: '/homepage',
        component: homepage,
        meta: {
          isShowFooter: true
        }
      },
      {
        path: '/personage',
        component: personage,
        meta: {
          isShowFooter: true
        }
      },
      {
        path: '/trolley',
        component: trolley,
        meta: {
          isShowFooter: true
        }
      }
]