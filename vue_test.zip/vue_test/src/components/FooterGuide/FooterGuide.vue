<template>
    <div id="footContainer">
        <div class="guideItem">
            <span>首页</span>
        </div>
        <div class="guideItem">
            <span>分类</span>
        </div>
        <div class="guideItem">
            <span>值得买</span>
        </div>
        <div class="guideItem">
            <span>购物车</span>
        </div>
        <div class="guideItem">
            <span>个人</span>
        </div>
    </div>
</template>

<script>
export default {
    
}
</script>

<style lang="">
    
</style>